## Running the app
Run code: docker-compose up
